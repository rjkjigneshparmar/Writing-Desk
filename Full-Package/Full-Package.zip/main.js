const { app, BrowserWindow, ipcMain, net } = require('electron');
const path = require('path');
const fs = require('fs');

const isDev = process.env.NODE_ENV === 'development';

// ─── Config helpers ───────────────────────────────────────────────────────────
function getConfigPath() {
  return path.join(app.getPath('userData'), 'config.json');
}

function readConfig() {
  try {
    const data = fs.readFileSync(getConfigPath(), 'utf8');
    return JSON.parse(data);
  } catch {
    return { provider: 'anthropic', model: 'claude-sonnet-4-20250514', keys: {} };
  }
}

function writeConfig(config) {
  fs.writeFileSync(getConfigPath(), JSON.stringify(config, null, 2), 'utf8');
}

// ─── Window ───────────────────────────────────────────────────────────────────
function createWindow() {
  const win = new BrowserWindow({
    width: 960,
    height: 860,
    minWidth: 620,
    minHeight: 600,
    title: 'The Writing Desk',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (isDev) {
    win.loadURL('http://localhost:5173');
  } else {
    win.loadFile(path.join(__dirname, '../dist/index.html'));
  }
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });

// ─── IPC: settings ────────────────────────────────────────────────────────────
ipcMain.handle('get-settings', () => {
  const c = readConfig();
  return { provider: c.provider || 'anthropic', model: c.model || 'claude-sonnet-4-20250514', keys: c.keys || {} };
});

ipcMain.handle('save-settings', (_, { provider, model, key }) => {
  const config = readConfig();
  config.provider = provider;
  config.model = model;
  if (!config.keys) config.keys = {};
  if (key) config.keys[provider] = key.trim();
  writeConfig(config);
  return true;
});

// ─── IPC: Claude API proxy ────────────────────────────────────────────────────
ipcMain.handle('call-claude', async (_, prompt) => {
  const config = readConfig();
  const provider = config.provider || 'anthropic';
  const model = config.model || 'claude-sonnet-4-20250514';
  const apiKey = (config.keys || {})[provider];

  if (!apiKey) throw new Error(`No API key set for ${provider}. Please go to Settings and add your key.`);

  if (provider === 'anthropic') return callAnthropic(apiKey, model, prompt);
  if (provider === 'openai')    return callOpenAI(apiKey, model, prompt);
  if (provider === 'google')    return callGoogle(apiKey, model, prompt);
  throw new Error('Unknown provider: ' + provider);
});

// ─── Anthropic ────────────────────────────────────────────────────────────────
function callAnthropic(apiKey, model, prompt) {
  return netRequest(
    'POST',
    'https://api.anthropic.com/v1/messages',
    { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    { model, max_tokens: 2500, messages: [{ role: 'user', content: prompt }] },
    (data) => (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n')
  );
}

// ─── OpenAI ───────────────────────────────────────────────────────────────────
function callOpenAI(apiKey, model, prompt) {
  return netRequest(
    'POST',
    'https://api.openai.com/v1/chat/completions',
    { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    { model, max_tokens: 2500, messages: [{ role: 'user', content: prompt }] },
    (data) => data.choices[0].message.content
  );
}

// ─── Google Gemini ────────────────────────────────────────────────────────────
function callGoogle(apiKey, model, prompt) {
  return netRequest(
    'POST',
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
    { 'Content-Type': 'application/json' },
    { contents: [{ parts: [{ text: prompt }] }], generationConfig: { maxOutputTokens: 2500 } },
    (data) => data.candidates[0].content.parts[0].text
  );
}

// ─── Shared net.request helper ────────────────────────────────────────────────
function netRequest(method, url, headers, body, parseResponse) {
  return new Promise((resolve, reject) => {
    const request = net.request({ method, url });
    Object.entries(headers).forEach(([k, v]) => request.setHeader(k, v));

    let responseBody = '';
    request.on('response', (response) => {
      response.on('data', (chunk) => { responseBody += chunk.toString(); });
      response.on('end', () => {
        if (response.statusCode !== 200) {
          reject(new Error(`API error ${response.statusCode}: ${responseBody.slice(0, 300)}`));
          return;
        }
        try {
          resolve(parseResponse(JSON.parse(responseBody)));
        } catch (e) {
          reject(new Error('Could not parse API response: ' + responseBody.slice(0, 200)));
        }
      });
    });

    request.on('error', (err) => reject(new Error('Network error: ' + err.message)));
    request.write(JSON.stringify(body));
    request.end();
  });
}
