import React, { useState, useEffect, useMemo } from "react";

const isElectron = typeof window !== "undefined" && !!window.electronAPI;

// ─── Provider / model config ──────────────────────────────────────────────────
const PROVIDERS = {
  anthropic: {
    label: "Anthropic",
    icon: "◆",
    placeholder: "sk-ant-api03-...",
    keyLink: "https://console.anthropic.com",
    keyLinkLabel: "console.anthropic.com",
    models: [
      { id: "claude-sonnet-4-20250514", label: "Claude Sonnet 4" },
      { id: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5" },
      { id: "claude-opus-4-6-20250514", label: "Claude Opus 4.6" },
    ],
    pricing: "~$0.003 / request",
  },
  openai: {
    label: "OpenAI",
    icon: "◇",
    placeholder: "sk-...",
    keyLink: "https://platform.openai.com/api-keys",
    keyLinkLabel: "platform.openai.com",
    models: [
      { id: "gpt-4o-mini", label: "GPT-4o Mini" },
      { id: "gpt-4o", label: "GPT-4o" },
      { id: "gpt-4-turbo", label: "GPT-4 Turbo" },
    ],
    pricing: "~$0.001–0.01 / request",
  },
  google: {
    label: "Google Gemini",
    icon: "✦",
    placeholder: "AIza...",
    keyLink: "https://aistudio.google.com/app/apikey",
    keyLinkLabel: "aistudio.google.com",
    models: [
      { id: "gemini-2.0-flash", label: "Gemini 2.0 Flash" },
      { id: "gemini-2.0-flash-lite", label: "Gemini 2.0 Flash Lite" },
      { id: "gemini-1.5-pro", label: "Gemini 1.5 Pro" },
    ],
    pricing: "Free tier available",
  },
};

export default function App() {
  const [view, setView] = useState("main");
  return view === "settings" ? (
    <SettingsPage onBack={() => setView("main")} />
  ) : (
    <WritingDesk onOpenSettings={() => setView("settings")} />
  );
}

// ════════════════════════════════════════════════════════════════════════════
// SETTINGS PAGE
// ════════════════════════════════════════════════════════════════════════════
function SettingsPage({ onBack }) {
  const [provider, setProvider] = useState("anthropic");
  const [model, setModel]       = useState("claude-sonnet-4-20250514");
  const [keys, setKeys]         = useState({});
  const [showKey, setShowKey]   = useState(false);
  const [saved, setSaved]       = useState(false);
  const [testing, setTesting]   = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [testMsg, setTestMsg]   = useState("");
  const [dark, setDark]         = useState(false);

  const t = useTheme(dark);
  const pInfo = PROVIDERS[provider];
  const currentKey = keys[provider] || "";

  useEffect(() => {
    if (isElectron) {
      window.electronAPI.getSettings().then((s) => {
        setProvider(s.provider || "anthropic");
        setModel(s.model || "claude-sonnet-4-20250514");
        setKeys(s.keys || {});
      });
    }
  }, []);

  function handleProviderChange(p) {
    setProvider(p);
    setModel(PROVIDERS[p].models[0].id);
    setTestResult(null);
    setSaved(false);
  }

  function handleKeyChange(val) {
    setKeys((prev) => ({ ...prev, [provider]: val }));
    setSaved(false);
    setTestResult(null);
  }

  async function handleSave() {
    if (!isElectron) return;
    await window.electronAPI.saveSettings({ provider, model, key: currentKey });
    setSaved(true);
    setTestResult(null);
    setTimeout(() => setSaved(false), 2500);
  }

  async function handleTest() {
    if (!isElectron || !currentKey.trim()) return;
    setTesting(true);
    setTestResult(null);
    await window.electronAPI.saveSettings({ provider, model, key: currentKey });
    try {
      await window.electronAPI.callClaude('Reply with exactly the word: OK');
      setTestResult("ok");
      setTestMsg(`Connection successful — ${pInfo.label} is working!`);
    } catch (err) {
      setTestResult("error");
      setTestMsg(err.message || "Connection failed. Check your key and try again.");
    } finally {
      setTesting(false);
    }
  }

  return (
    <div style={{ minHeight: "100vh", background: t.bg, color: t.text, fontFamily: "'Crimson Pro', Georgia, serif", padding: "28px 24px 60px" }}>
      <style>{`* { box-sizing: border-box; } button { transition: all 0.15s ease; cursor: pointer; } button:active { transform: scale(0.97); } input:focus { outline: none; border-color: ${t.accent} !important; }`}</style>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}>
        <button onClick={onBack} style={{ background: "transparent", border: `1px solid ${t.border}`, color: t.muted, padding: "8px 14px", borderRadius: 2, fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase" }}>
          ← Back
        </button>
        <button onClick={() => setDark(!dark)} style={{ background: t.card, border: `1px solid ${t.border}`, width: 36, height: 36, borderRadius: 18, fontSize: 16, color: t.text, padding: 0 }}>
          {dark ? "☀" : "☾"}
        </button>
      </div>

      <div style={{ maxWidth: 540, margin: "0 auto" }}>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.25em", textTransform: "uppercase", color: t.muted, marginBottom: 8 }}>⊹ Configuration ⊹</div>
        <h2 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 32, fontStyle: "italic", margin: "0 0 28px" }}>Settings</h2>

        {/* ── Provider selector ── */}
        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 4, padding: 20, marginBottom: 14, boxShadow: t.shadow }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 14 }}>AI Provider</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {Object.entries(PROVIDERS).map(([id, info]) => {
              const active = provider === id;
              return (
                <button key={id} onClick={() => handleProviderChange(id)} style={{ flex: 1, minWidth: 120, background: active ? t.inkBtn : t.cardAlt, color: active ? t.inkBtnText : t.textSoft, border: `1px solid ${active ? t.inkBtn : t.border}`, padding: "12px 10px", borderRadius: 2, fontFamily: "'Fraunces', serif", fontSize: 15 }}>
                  <div style={{ fontSize: 18, marginBottom: 4 }}>{info.icon}</div>
                  <div style={{ fontWeight: active ? 600 : 400 }}>{info.label}</div>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, marginTop: 4, opacity: 0.7 }}>{info.pricing}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ── Model selector ── */}
        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 4, padding: 20, marginBottom: 14, boxShadow: t.shadow }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 12 }}>Model</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {pInfo.models.map((m) => {
              const active = model === m.id;
              return (
                <button key={m.id} onClick={() => setModel(m.id)} style={{ background: active ? t.chipActive : t.chipBg, color: active ? t.chipActiveText : t.textSoft, border: `1px solid ${active ? t.chipActive : t.border}`, padding: "8px 14px", borderRadius: 100, fontFamily: "'Crimson Pro', serif", fontSize: 14 }}>
                  {m.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* ── API Key ── */}
        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 4, padding: 20, marginBottom: 14, boxShadow: t.shadow }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 10 }}>
            {pInfo.label} API Key
          </div>
          <div style={{ fontFamily: "'Crimson Pro', serif", fontSize: 15, color: t.textSoft, lineHeight: 1.5, marginBottom: 14 }}>
            Your key is stored locally and never shared. Each provider needs its own key.
          </div>

          <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
            <input
              type={showKey ? "text" : "password"}
              value={currentKey}
              onChange={(e) => handleKeyChange(e.target.value)}
              placeholder={pInfo.placeholder}
              style={{ flex: 1, background: t.cardAlt, border: `1px solid ${t.border}`, borderRadius: 2, padding: "11px 14px", fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: t.text }}
            />
            <button onClick={() => setShowKey(!showKey)} style={{ background: "transparent", border: `1px solid ${t.border}`, color: t.muted, padding: "11px 14px", borderRadius: 2, fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", whiteSpace: "nowrap" }}>
              {showKey ? "Hide" : "Show"}
            </button>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={handleSave} disabled={!currentKey.trim()} style={{ flex: 1, background: !currentKey.trim() ? t.mutedDim : t.inkBtn, color: t.inkBtnText, border: "none", padding: "13px", fontFamily: "'Fraunces', serif", fontSize: 16, borderRadius: 2 }}>
              {saved ? "✓ Saved" : "Save Settings"}
            </button>
            <button onClick={handleTest} disabled={!currentKey.trim() || testing} style={{ flex: 1, background: "transparent", color: !currentKey.trim() ? t.mutedDim : t.text, border: `1px solid ${!currentKey.trim() ? t.mutedDim : t.text}`, padding: "13px", fontFamily: "'Fraunces', serif", fontSize: 16, borderRadius: 2 }}>
              {testing ? "Testing…" : "Test Connection"}
            </button>
          </div>
        </div>

        {/* Test result */}
        {testResult && (
          <div style={{ background: testResult === "ok" ? t.accentSoft : t.redBg, border: `1px solid ${testResult === "ok" ? t.accent : t.redBorder}`, color: testResult === "ok" ? t.accent : t.red, padding: "12px 16px", borderRadius: 2, fontFamily: "'Crimson Pro', serif", fontSize: 15, marginBottom: 14 }}>
            {testResult === "ok" ? "✓ " : "✕ "}{testMsg}
          </div>
        )}

        {/* Where to get key */}
        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 4, padding: 18 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 10 }}>
            How to get a {pInfo.label} key
          </div>
          <ol style={{ margin: 0, paddingLeft: 20, lineHeight: 1.8, color: t.textSoft, fontSize: 15 }}>
            <li>Go to <strong style={{ color: t.text }}>{pInfo.keyLinkLabel}</strong></li>
            <li>Sign up or log in</li>
            <li>Navigate to <strong style={{ color: t.text }}>API Keys</strong> and create a new key</li>
            <li>Paste it above and click <strong style={{ color: t.text }}>Save Settings</strong></li>
          </ol>
          <div style={{ marginTop: 12, padding: "10px 14px", background: t.cardAlt, borderRadius: 2, fontFamily: "'Crimson Pro', serif", fontSize: 14, color: t.muted, fontStyle: "italic" }}>
            Pricing: {pInfo.pricing}
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// WRITING DESK
// ════════════════════════════════════════════════════════════════════════════
function WritingDesk({ onOpenSettings }) {
  const [text, setText]                     = useState("");
  const [mode, setMode]                     = useState("check");
  const [tone, setTone]                     = useState("keep");
  const [rewriteStyle, setRewriteStyle]     = useState("clearer");
  const [emailRecipient, setEmailRecipient] = useState("colleague");
  const [translateFrom, setTranslateFrom]   = useState("auto");
  const [socialPlatform, setSocialPlatform] = useState("twitter");
  const [result, setResult]                 = useState(null);
  const [loading, setLoading]               = useState(false);
  const [error, setError]                   = useState(null);
  const [dark, setDark]                     = useState(false);
  const [copied, setCopied]                 = useState(false);
  const [selectedAlt, setSelectedAlt]       = useState(0);
  const [noKey, setNoKey]                   = useState(false);
  const [activeProvider, setActiveProvider] = useState("anthropic");

  const t = useTheme(dark);

  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,700&family=Crimson+Pro:ital,wght@0,400;0,500;1,400&family=JetBrains+Mono:wght@400;500&display=swap";
    document.head.appendChild(link);
  }, []);

  useEffect(() => {
    if (isElectron) {
      window.electronAPI.getSettings().then((s) => {
        const p = s.provider || "anthropic";
        setActiveProvider(p);
        const hasKey = !!(s.keys || {})[p];
        setNoKey(!hasKey);
      });
    }
  }, []);

  const wordCount = text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
  const charCount = text.length;

  async function callClaude(prompt) {
    if (isElectron) return window.electronAPI.callClaude(prompt);
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 2500, messages: [{ role: "user", content: prompt }] }),
    });
    if (!response.ok) throw new Error(`API ${response.status}`);
    const data = await response.json();
    return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
  }

  function buildPrompt() {
    const shape = `Respond with ONLY a single JSON object — no markdown fences, no commentary. Shape:
{"issues":[{"type":"spelling|grammar|punctuation|clarity|tone","original":"<exact phrase>","correction":"<fix>","explanation":"<one short sentence>"}],"polishedText":"<final polished version>","alternatives":["<alt 1>","<alt 2>"],"overallNote":"<one short encouraging sentence>"}
If a field doesn't apply, use empty array or empty string. Always include polishedText.`;

    if (mode === "check") {
      const toneMap = { keep: "Preserve the writer's natural voice.", professional: "Make the tone professional and polished.", friendly: "Make the tone warm and friendly.", casual: "Make the tone casual and conversational.", formal: "Make the tone formal and respectful.", concise: "Tighten the writing — shorter sentences, fewer words." };
      return `You are a careful, friendly editor. Analyze the text for spelling, grammar, punctuation, and clarity issues. ${toneMap[tone]} List the most impactful issues (max 8). The polishedText should reflect all corrections.\n\n${shape}\n\nText:\n${JSON.stringify(text)}`;
    }
    if (mode === "rewrite") {
      const styleMap = { shorter: "much shorter and more direct", longer: "longer, more developed, and detailed", polite: "more polite and considerate", confident: "more confident and assertive", clearer: "clearer and easier to understand", simpler: "simpler — use plain everyday words" };
      return `Rewrite the text to be ${styleMap[rewriteStyle]}. Put the main version in polishedText, provide 2 alternatives. Issues should be empty unless there's an actual error.\n\n${shape}\n\nText:\n${JSON.stringify(text)}`;
    }
    if (mode === "email") {
      const recipMap = { boss: "the writer's manager — respectful but not stiff", colleague: "a peer — warm and collaborative", client: "an external client — professional and clear", friend: "a friend — casual and warm" };
      return `Polish this draft as an email to ${recipMap[emailRecipient]}. Check tone, clarity, structure, greeting and sign-off. Put the full polished email in polishedText.\n\n${shape}\n\nEmail draft:\n${JSON.stringify(text)}`;
    }
    if (mode === "translate") {
      const fromMap = { auto: "auto-detect the source language", hindi: "the source is Hindi", gujarati: "the source is Gujarati", spanish: "the source is Spanish", french: "the source is French", german: "the source is German" };
      return `Translate the text into polished, natural English. ${fromMap[translateFrom]}. If already English, just polish it. Put the final version in polishedText with 1-2 alternatives.\n\n${shape}\n\nText:\n${JSON.stringify(text)}`;
    }
    if (mode === "social") {
      const platforms = { twitter: { name: "Twitter/X", limit: 280 }, linkedin: { name: "LinkedIn", limit: 3000 }, sms: { name: "SMS", limit: 160 }, instagram: { name: "Instagram caption", limit: 2200 } };
      const p = platforms[socialPlatform];
      return `Polish this text for ${p.name}. Must be ${p.limit} chars or fewer. Make it engaging and platform-appropriate. Put the main version in polishedText with 2 alternatives.\n\n${shape}\n\nText:\n${JSON.stringify(text)}`;
    }
  }

  async function run() {
    if (!text.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);
    setCopied(false);
    setSelectedAlt(0);
    try {
      const raw = await callClaude(buildPrompt());
      if (!raw) throw new Error("Empty response");
      const first = raw.indexOf("{"), last = raw.lastIndexOf("}");
      if (first === -1 || last === -1) throw new Error("No JSON in response");
      let parsed;
      try { parsed = JSON.parse(raw.slice(first, last + 1)); }
      catch { parsed = JSON.parse(raw.slice(first, last + 1).replace(/[\u201C\u201D]/g, '"').replace(/[\u2018\u2019]/g, "'").replace(/[\u0000-\u001F]+/g, " ")); }
      if (!Array.isArray(parsed.issues)) parsed.issues = [];
      if (!Array.isArray(parsed.alternatives)) parsed.alternatives = [];
      if (typeof parsed.polishedText !== "string") parsed.polishedText = text;
      setResult(parsed);
      setNoKey(false);
    } catch (err) {
      const msg = err?.message || String(err);
      if (msg.includes("No API key")) setNoKey(true);
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  function getActivePolished() {
    if (!result) return "";
    if (selectedAlt === 0) return result.polishedText;
    return result.alternatives[selectedAlt - 1] || result.polishedText;
  }

  function applyPolished() {
    const v = getActivePolished();
    if (v) { setText(v); setResult(null); }
  }

  function copyPolished() {
    const target = getActivePolished();
    if (!target) return;
    const doCopy = () => {
      const el = document.createElement("textarea");
      el.value = target;
      el.style.cssText = "position:fixed;top:-9999px;left:-9999px;opacity:0;";
      document.body.appendChild(el);
      el.focus();
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    };
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(target).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }).catch(doCopy);
    } else { doCopy(); }
  }

  function clearAll() { setText(""); setResult(null); setError(null); setSelectedAlt(0); }

  const modeTabs = [
    { id: "check", label: "Check", icon: "✓" },
    { id: "rewrite", label: "Rewrite", icon: "↻" },
    { id: "email", label: "Email", icon: "✉" },
    { id: "translate", label: "Translate", icon: "⇆" },
    { id: "social", label: "Social", icon: "◎" },
  ];

  const optionsForMode = {
    check:     { label: "Tone",      value: tone,           setter: setTone,           options: [{ id: "keep", label: "Keep my voice" }, { id: "professional", label: "Professional" }, { id: "friendly", label: "Friendly" }, { id: "casual", label: "Casual" }, { id: "formal", label: "Formal" }, { id: "concise", label: "Concise" }] },
    rewrite:   { label: "Style",     value: rewriteStyle,   setter: setRewriteStyle,   options: [{ id: "shorter", label: "Shorter" }, { id: "longer", label: "Longer" }, { id: "polite", label: "More polite" }, { id: "confident", label: "More confident" }, { id: "clearer", label: "Clearer" }, { id: "simpler", label: "Simpler" }] },
    email:     { label: "Recipient", value: emailRecipient, setter: setEmailRecipient, options: [{ id: "boss", label: "Boss" }, { id: "colleague", label: "Colleague" }, { id: "client", label: "Client" }, { id: "friend", label: "Friend" }] },
    translate: { label: "From",      value: translateFrom,  setter: setTranslateFrom,  options: [{ id: "auto", label: "Auto-detect" }, { id: "hindi", label: "Hindi" }, { id: "gujarati", label: "Gujarati" }, { id: "spanish", label: "Spanish" }, { id: "french", label: "French" }, { id: "german", label: "German" }] },
    social:    { label: "Platform",  value: socialPlatform, setter: setSocialPlatform, options: [{ id: "twitter", label: "Twitter · 280" }, { id: "linkedin", label: "LinkedIn · 3K" }, { id: "sms", label: "SMS · 160" }, { id: "instagram", label: "Instagram · 2200" }] },
  };

  const currentOpts = optionsForMode[mode];
  const ctaLabel = { check: "Check my writing", rewrite: "Rewrite", email: "Polish email", translate: "Translate & polish", social: "Polish for posting" }[mode];
  const providerInfo = PROVIDERS[activeProvider] || PROVIDERS.anthropic;

  const typeColors = {
    spelling:    { bg: dark ? "#3D2820" : "#F2E4DC", text: dark ? "#E5A88E" : "#8B3A1F" },
    grammar:     { bg: dark ? "#33253A" : "#E8DDE8", text: dark ? "#C8A0CC" : "#5B2E5B" },
    punctuation: { bg: dark ? "#2A3220" : "#E0E5D5", text: dark ? "#A8C28F" : "#3F5230" },
    clarity:     { bg: dark ? "#36301F" : "#E5DCC8", text: dark ? "#D4B97A" : "#6B4E1F" },
    tone:        { bg: dark ? "#2A3242" : "#DCE2EC", text: dark ? "#9AB4D4" : "#2C4566" },
  };

  return (
    <div style={{ minHeight: "100vh", background: t.bg, color: t.text, fontFamily: "'Crimson Pro', Georgia, serif", padding: "20px 18px 60px", transition: "background 0.3s ease, color 0.3s ease" }}>
      <style>{`
        * { box-sizing: border-box; }
        textarea::placeholder { color: ${t.mutedDim}; font-style: italic; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .fade-in { animation: fadeIn 0.3s ease-out both; }
        .loading-dot { animation: pulse 1.2s ease-in-out infinite; display: inline-block; }
        button:active:not(:disabled) { transform: scale(0.97); }
        button { transition: all 0.15s ease; cursor: pointer; }
        button:disabled { cursor: default; }
        .tabs-scroll::-webkit-scrollbar { display: none; }
        .tabs-scroll { -ms-overflow-style: none; scrollbar-width: none; }
        .compare-grid { display: grid; grid-template-columns: 1fr; gap: 14px; }
        @media (min-width: 760px) { .compare-grid { grid-template-columns: 1fr 1fr; } }
      `}</style>

      {/* Header */}
      <header style={{ marginBottom: 20, position: "relative" }}>
        <div style={{ position: "absolute", top: 4, right: 0, display: "flex", gap: 8, alignItems: "center" }}>
          {/* Active provider badge */}
          <div onClick={onOpenSettings} title="Click to change provider" style={{ background: t.card, border: `1px solid ${t.border}`, padding: "6px 10px", borderRadius: 100, fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.15em", textTransform: "uppercase", color: t.muted, cursor: "pointer", whiteSpace: "nowrap" }}>
            {providerInfo.icon} {providerInfo.label}
          </div>
          <button onClick={() => setDark(!dark)} style={{ background: t.card, border: `1px solid ${t.border}`, width: 36, height: 36, borderRadius: 18, fontSize: 16, color: t.text, padding: 0 }}>
            {dark ? "☀" : "☾"}
          </button>
          <button onClick={onOpenSettings} title="Settings" style={{ background: t.card, border: `1px solid ${t.border}`, width: 36, height: 36, borderRadius: 18, fontSize: 16, color: t.text, padding: 0 }}>
            ⚙
          </button>
        </div>
        <div style={{ textAlign: "center", paddingTop: 4 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.25em", textTransform: "uppercase", color: t.muted, marginBottom: 8 }}>⊹ Your personal editor · v4 ⊹</div>
          <h1 style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, fontSize: 36, lineHeight: 1.05, margin: 0, fontStyle: "italic", letterSpacing: "-0.02em" }}>
            The Writing <span style={{ fontWeight: 700, fontStyle: "normal" }}>Desk.</span>
          </h1>
        </div>
      </header>

      {/* No key banner */}
      {noKey && (
        <div onClick={onOpenSettings} style={{ background: t.redBg, border: `1px solid ${t.redBorder}`, color: t.red, padding: "12px 16px", borderRadius: 2, marginBottom: 16, fontFamily: "'Crimson Pro', serif", fontSize: 15, cursor: "pointer", textAlign: "center" }}>
          ⚠ No API key set for {providerInfo.label}. <strong>Click here to open Settings.</strong>
        </div>
      )}

      {/* Mode tabs */}
      <div className="tabs-scroll" style={{ display: "flex", gap: 4, marginBottom: 14, overflowX: "auto", padding: "4px 0", borderBottom: `1px solid ${t.border}` }}>
        {modeTabs.map((mt) => (
          <button key={mt.id} onClick={() => { setMode(mt.id); setResult(null); setError(null); }} style={{ background: "transparent", border: "none", padding: "10px 14px", fontFamily: "'Fraunces', serif", fontSize: 15, fontWeight: mode === mt.id ? 600 : 400, color: mode === mt.id ? t.text : t.muted, borderBottom: `2px solid ${mode === mt.id ? t.text : "transparent"}`, marginBottom: -1, whiteSpace: "nowrap", flexShrink: 0 }}>
            <span style={{ marginRight: 6 }}>{mt.icon}</span>{mt.label}
          </button>
        ))}
      </div>

      {/* Mode options */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 8 }}>{currentOpts.label}</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {currentOpts.options.map((opt) => {
            const active = currentOpts.value === opt.id;
            return (
              <button key={opt.id} onClick={() => currentOpts.setter(opt.id)} style={{ background: active ? t.chipActive : t.chipBg, color: active ? t.chipActiveText : t.textSoft, border: `1px solid ${active ? t.chipActive : t.border}`, padding: "7px 12px", fontFamily: "'Crimson Pro', serif", fontSize: 14, borderRadius: 100 }}>
                {opt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Draft input */}
      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 4, padding: 16, boxShadow: t.shadow, marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase", color: t.muted }}>
          <span>Your draft</span>
          <span>{wordCount} {wordCount === 1 ? "word" : "words"} · {charCount} chars</span>
        </div>
        <textarea value={text} onChange={(e) => setText(e.target.value)}
          placeholder={mode === "translate" ? "Write in any language — get polished English back…" : mode === "email" ? "Draft your email here…" : mode === "social" ? "Draft your post here…" : "Start writing or paste a message you want to polish…"}
          rows={6} style={{ width: "100%", border: "none", outline: "none", background: "transparent", fontFamily: "'Crimson Pro', Georgia, serif", fontSize: 17, lineHeight: 1.55, color: t.text, resize: "vertical", minHeight: 130 }} />
      </div>

      {/* Actions */}
      <div style={{ display: "flex", gap: 10, marginBottom: 18 }}>
        <button onClick={run} disabled={loading || !text.trim()} style={{ flex: 1, background: !text.trim() || loading ? t.mutedDim : t.inkBtn, color: t.inkBtnText, border: "none", padding: "15px 20px", fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 500, borderRadius: 2 }}>
          {loading ? <span>Working<span className="loading-dot">.</span><span className="loading-dot" style={{ animationDelay: "0.2s" }}>.</span><span className="loading-dot" style={{ animationDelay: "0.4s" }}>.</span></span> : ctaLabel}
        </button>
        {text && (
          <button onClick={clearAll} style={{ background: "transparent", color: t.muted, border: `1px solid ${t.border}`, padding: "15px 14px", fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase", borderRadius: 2 }}>
            Clear
          </button>
        )}
      </div>

      {/* Error */}
      {error && (
        <div style={{ background: t.redBg, border: `1px solid ${t.redBorder}`, color: t.red, padding: 14, borderRadius: 2, fontSize: 13, fontFamily: "'JetBrains Mono', monospace", whiteSpace: "pre-wrap", wordBreak: "break-word", marginBottom: 18, lineHeight: 1.5 }}>
          {error}
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="fade-in">
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.25em", textTransform: "uppercase", color: t.muted, marginBottom: 10, textAlign: "center" }}>─── Editor's notes ───</div>

          {result.overallNote && (
            <p style={{ fontFamily: "'Fraunces', serif", fontStyle: "italic", fontSize: 17, lineHeight: 1.4, textAlign: "center", color: t.accent, margin: "0 0 22px", padding: "0 8px" }}>"{result.overallNote}"</p>
          )}

          {result.issues.length > 0 && (
            <div style={{ marginBottom: 22 }}>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 10 }}>
                {result.issues.length} {result.issues.length === 1 ? "suggestion" : "suggestions"}
              </div>
              {result.issues.map((issue, i) => {
                const c = typeColors[issue.type] || typeColors.grammar;
                return (
                  <div key={i} className="fade-in" style={{ background: t.card, border: `1px solid ${t.border}`, borderLeft: `3px solid ${c.text}`, padding: 14, marginBottom: 10, borderRadius: 2, animationDelay: `${i * 0.05}s` }}>
                    <div style={{ display: "inline-block", background: c.bg, color: c.text, fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", padding: "3px 8px", borderRadius: 2, marginBottom: 8 }}>{issue.type || "grammar"}</div>
                    <div style={{ fontSize: 16, lineHeight: 1.5, marginBottom: 6 }}>
                      <span style={{ textDecoration: "line-through", textDecorationColor: t.red, color: t.muted }}>{issue.original}</span>
                      <span style={{ margin: "0 8px", color: t.mutedDim }}>→</span>
                      <span style={{ color: t.accent, fontWeight: 500 }}>{issue.correction}</span>
                    </div>
                    <div style={{ fontSize: 14, lineHeight: 1.45, color: t.textSoft, fontStyle: "italic" }}>{issue.explanation}</div>
                  </div>
                );
              })}
            </div>
          )}

          {result.polishedText && (
            <div>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 10, textAlign: "center" }}>─── Original ↔ Polished ───</div>
              <div className="compare-grid">
                <div style={{ background: t.cardAlt, border: `1px solid ${t.border}`, borderRadius: 4, padding: 16 }}>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 10 }}>Original · {text.length} chars</div>
                  <div style={{ fontSize: 16, lineHeight: 1.55, color: t.textSoft, whiteSpace: "pre-wrap" }}>{text}</div>
                </div>
                <div style={{ background: t.card, border: `1px solid ${t.accent}`, borderRadius: 4, padding: 16 }}>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.accent, marginBottom: 10 }}>Polished · {getActivePolished().length} chars</div>
                  <div style={{ fontSize: 16, lineHeight: 1.55, color: t.text, whiteSpace: "pre-wrap", marginBottom: 14 }}>{getActivePolished()}</div>
                  {result.alternatives?.length > 0 && (
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.2em", textTransform: "uppercase", color: t.muted, marginBottom: 8 }}>Versions</div>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {["Main", ...result.alternatives.map((_, i) => `Alt ${i + 1}`)].map((lbl, i) => (
                          <button key={i} onClick={() => setSelectedAlt(i)} style={{ background: selectedAlt === i ? t.accent : "transparent", color: selectedAlt === i ? (dark ? t.bg : "#FFF") : t.textSoft, border: `1px solid ${selectedAlt === i ? t.accent : t.border}`, padding: "5px 10px", fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", borderRadius: 100 }}>
                            {lbl}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div style={{ display: "flex", gap: 8 }}>
                    <button onClick={copyPolished} style={{ flex: 1, background: copied ? t.accent : t.inkBtn, color: copied ? (dark ? t.bg : "#FFF") : t.inkBtnText, border: "none", padding: "11px", fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase", borderRadius: 2 }}>
                      {copied ? "✓ Copied" : "Copy"}
                    </button>
                    <button onClick={applyPolished} style={{ flex: 1, background: "transparent", color: t.text, border: `1px solid ${t.text}`, padding: "11px", fontFamily: "'JetBrains Mono', monospace", fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase", borderRadius: 2 }}>
                      Apply
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      <footer style={{ marginTop: 36, textAlign: "center", fontFamily: "'JetBrains Mono', monospace", fontSize: 9, letterSpacing: "0.25em", textTransform: "uppercase", color: t.mutedDim }}>
        ⊹ check · rewrite · email · translate · social ⊹
      </footer>
    </div>
  );
}

// ─── Shared theme hook ────────────────────────────────────────────────────────
function useTheme(dark) {
  return useMemo(() => dark ? {
    bg: "#1A1612", card: "#25201A", cardAlt: "#2D2820", border: "#3A3127",
    text: "#F0E8D8", textSoft: "#D8CFBC", muted: "#9C9286", mutedDim: "#6E6555",
    accent: "#A8C28F", accentSoft: "#3A4A30", red: "#D9756A", redBg: "#3A2620", redBorder: "#5A3A30",
    inkBtn: "#F0E8D8", inkBtnText: "#1A1612", chipBg: "#2D2820", chipActive: "#F0E8D8", chipActiveText: "#1A1612",
    shadow: "0 1px 0 #3A3127, 0 12px 30px -20px rgba(0,0,0,0.5)",
  } : {
    bg: "#FAF6EE", card: "#FFFDF7", cardAlt: "#F5EFE0", border: "#E8DFC9",
    text: "#1F1B16", textSoft: "#3A332A", muted: "#8B7E6B", mutedDim: "#B5AB97",
    accent: "#4A6B3A", accentSoft: "#E0E5D5", red: "#B23A2C", redBg: "#F5E1DC", redBorder: "#D9A89C",
    inkBtn: "#1F1B16", inkBtnText: "#FAF6EE", chipBg: "#FFFDF7", chipActive: "#1F1B16", chipActiveText: "#FAF6EE",
    shadow: "0 1px 0 #E8DFC9, 0 12px 30px -20px rgba(31,27,22,0.25)",
  }, [dark]);
}
