const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getSettings:   ()                         => ipcRenderer.invoke('get-settings'),
  saveSettings:  ({ provider, model, key }) => ipcRenderer.invoke('save-settings', { provider, model, key }),
  callClaude:    (prompt)                   => ipcRenderer.invoke('call-claude', prompt),
});
